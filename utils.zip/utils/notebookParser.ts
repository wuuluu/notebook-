
import { NotebookCell, NotebookContent, SplitFile } from '../types';

/**
 * Normalizes cell source which can be a string or an array of strings.
 */
const normalizeSource = (source: string | string[]): string => {
  if (Array.isArray(source)) {
    return source.join('');
  }
  return source;
};

/**
 * Converts a notebook cell to its Python representation.
 */
const cellToPython = (cell: NotebookCell, index: number): string => {
  const source = normalizeSource(cell.source);
  const header = `# --- Cell ${index + 1} (${cell.cell_type}) ---\n`;
  
  if (cell.cell_type === 'markdown') {
    // Convert markdown to multi-line docstring or comments
    const lines = source.split('\n');
    return `${header}"""\n${source}\n"""\n\n`;
  } else if (cell.cell_type === 'code') {
    return `${header}${source}\n\n`;
  } else {
    return `${header}# [Raw Cell Content]\n# ${source.replace(/\n/g, '\n# ')}\n\n`;
  }
};

/**
 * Splits the notebook content into chunks of N cells.
 */
export const splitNotebook = (notebook: NotebookContent, chunkSize: number = 3): SplitFile[] => {
  const { cells } = notebook;
  const files: SplitFile[] = [];
  
  for (let i = 0; i < cells.length; i += chunkSize) {
    const chunk = cells.slice(i, i + chunkSize);
    const content = chunk
      .map((cell, idx) => cellToPython(cell, i + idx))
      .join('\n');
    
    const partNumber = Math.floor(i / chunkSize) + 1;
    files.push({
      id: `file-${partNumber}`,
      name: `part_${partNumber.toString().padStart(3, '0')}.py`,
      content,
      cellIndices: Array.from({ length: chunk.length }, (_, k) => i + k)
    });
  }
  
  return files;
};

/**
 * Safely parses the ipynb JSON.
 */
export const parseNotebook = (jsonString: string): NotebookContent => {
  try {
    return JSON.parse(jsonString) as NotebookContent;
  } catch (err) {
    throw new Error('Invalid .ipynb file format. Please upload a valid Jupyter Notebook.');
  }
};
